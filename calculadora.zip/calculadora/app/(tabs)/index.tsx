import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import Display from '@/components/Display';
import Button from '@/components/Button';

export default function HomeScreen() {
  const [display, setDisplay] = useState('');
  const [result, setResult] = useState('');

  const handlePress = (input: string) => {
    if (input === 'C') {
      setDisplay('');
      setResult('');
    } else if (input === '=') {
      try {
        setResult(eval(display).toString());
      } catch {
        setResult('Erro');
      }
    } else {
      setDisplay(display + input);
    }
  };

  const buttons = [
    ['7', '8', '9', '/'],
    ['4', '5', '6', '*'],
    ['1', '2', '3', '-'],
    ['0', '.', 'C', '+'],
    ['='],
  ];

  return (
    <View style={styles.container}>
      <Display value={display} result={result} />
      <View style={styles.buttons}>
        {buttons.map((row, i) => (
          <View key={i} style={styles.row}>
            {row.map((btn) => (
              <Button key={btn} label={btn} onPress={() => handlePress(btn)} />
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#202020',
    padding: 10,
  },
  buttons: {
    marginTop: 20,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 2,
  },
  

});
