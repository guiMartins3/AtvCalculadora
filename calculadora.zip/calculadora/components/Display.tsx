import React from 'react';
import { View, Text } from 'react-native';
import styles from '@/styles/displayStyles';

type Props = {
  value: string;
  result: string;
};

const Display: React.FC<Props> = ({ value, result }) => (
  <View style={styles.container}>
    <Text style={styles.input}>{value}</Text>
    <Text style={styles.result}>{result}</Text>
  </View>
);

export default Display;
