import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  button: {
    backgroundColor: '#333',
    paddingVertical: 25,
    paddingHorizontal: 0,
    margin: 20,
    borderRadius: 8,
    flex: 1, 
    alignItems: 'center',
    justifyContent: 'center',

  },
  text: {
    fontSize: 24,
    color: '#fff',
  },
});
