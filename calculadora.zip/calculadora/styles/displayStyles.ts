import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  container: {
    backgroundColor: '#1c1c1c',
    padding: 20,
    borderRadius: 10,
  },
  input: {
    color: '#fff',
    fontSize: 30,
    textAlign: 'right',
  },
  result: {
    color: '#0f0',
    fontSize: 24,
    textAlign: 'right',
    marginTop: 10,
  },
});
